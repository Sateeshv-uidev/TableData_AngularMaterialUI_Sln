export interface Asset{
    id: number;
    title: string;
    author: string;
    price: number;
}